// ===========================================================================
// Reader table: reader code, department, per-reader device key.
//
// TEXTRACER_PLACEHOLDER_KEYS
// ^ This marker means the file is still the placeholder. Generate the real one from YOUR backend with:
//     node hardware_integration/tools/provision_reader_keys.mjs
//   (it overwrites this file only while the marker is present, and never prints keys to the screen).
//
// Order = physical reader number 1..9 (reader #1 is wired to SS GPIO 27, #2 to GPIO 12, ... see the .ino).
// ===========================================================================
#pragma once

struct ReaderDef {
  const char* code;        // readers.reader_code in the database (what the backend expects in "readerCode")
  const char* stage;       // stage the reader belongs to
  int         departmentId;// departments.id of that stage in the database
  const char* department;  // departments.name
  const char* key;         // X-Reader-Key (plain key; only its SHA-256 is stored in the database)
};

static const ReaderDef READER_DEFS[] = {
  {"RDR-RM1",    "raw_material_1",  1, "Procurement",   "REPLACE_WITH_PROVISIONED_KEY"},
  {"RDR-RM2",    "raw_material_2",  1, "Procurement",   "REPLACE_WITH_PROVISIONED_KEY"},
  {"RDR-DESIGN", "design",          2, "Design",        "REPLACE_WITH_PROVISIONED_KEY"},
  {"RDR-MFG1",   "manufacturing_1", 3, "Manufacturing", "REPLACE_WITH_PROVISIONED_KEY"},
  {"RDR-MFG2",   "manufacturing_2", 3, "Manufacturing", "REPLACE_WITH_PROVISIONED_KEY"},
  {"RDR-PROD",   "production",      4, "Production",    "REPLACE_WITH_PROVISIONED_KEY"},
  {"RDR-STITCH", "stitching",       5, "Stitching + QC Gate", "REPLACE_WITH_PROVISIONED_KEY"},
  {"RDR-PACK",   "packaging",       6, "Packaging",     "REPLACE_WITH_PROVISIONED_KEY"},
  {"RDR-SHIP",   "shipping",        7, "Shipping",      "REPLACE_WITH_PROVISIONED_KEY"},
};
